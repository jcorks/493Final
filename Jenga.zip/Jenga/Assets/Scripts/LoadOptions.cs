﻿using UnityEngine;
using System.Collections;

public class LoadOptions : MonoBehaviour {

	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
	
	}
	
	public void loadOptions(){
		Application.LoadLevel("OptionsMenu");
	}
}
